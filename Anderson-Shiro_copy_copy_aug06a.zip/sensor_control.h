// for temperature sensor
#include <DallasTemperature.h>
#include <OneWire.h>

// ***** pH SENSOR *****
const int PH_SENSOR = 34;
unsigned long lastPhRead = 0;
const  unsigned long PH_DELAY = 30;
int pH_buffer[10];
int ph_temp;
float pH_mV;
//float ph_offset = 0; // use this for user calibration

// ***** EC SENSOR *****
const int EC_SENSOR = 33;

int ec_buffer[10]; // buffer for storing ec adc readings
int ec_temp = 0;
unsigned long int raw_EC_ADC;
float ec_mV;  // voltage after filtering
//int ec_offset = 0; // use this for user calibration

unsigned long lastECRead = 0;
const unsigned long EC_DELAY = 30;



const int WATER_TMP = 19;
// Setup a oneWire instance to communicate with any OneWire device - water temp sensor
OneWire oneWire(WATER_TMP);	
// Pass oneWire reference to DallasTemperature library
DallasTemperature sensors(&oneWire);


unsigned long int lastWtrLevelRead = 0;
const int WATER_LVL = 5; // water level sensor pin
bool waterLevelSts = true; // default to true

void wtrLevel(){
  waterLevelSts = digitalRead(WATER_LVL);
  // take a reading every 10 seconds
  if(millis()-lastWtrLevelRead > 10000){
    lastWtrLevelRead = millis();
    //water_level = digitalRead(WATER_LVL);
    //Serial.print("Propper Water Level: ");
    //Serial.println(digitalRead(WATER_LVL));
    
  }
}


void wtrTemp(){
  // Send the command to get temperatures
  sensors.requestTemperatures(); 
/*
  //print the temperature in Celsius
  Serial.print("Temperature: ");
  Serial.print(sensors.getTempCByIndex(0));
  //Serial.print((char)176);//shows degrees character
  Serial.println("C  |  ");
*/
  water_temp = sensors.getTempCByIndex(0);
 // Serial.print("Water Temperature: ");
  //Serial.println(water_temp);
}

void pH(){
  
  // read every 5 seconds
  if (millis()-lastPhRead > 5000){
    lastPhRead = millis();
    // collect 10 adc values
    for (int i = 0; i<10; i++){
      pH_buffer[i] = analogRead(PH_SENSOR);
    }
    // order the adc values
    for(int i=0;i<9;i++) {
      for(int j=i+1;j<10;j++){
        if(pH_buffer[i]>pH_buffer[j]){  
          ph_temp = pH_buffer[i];
          pH_buffer[i]=pH_buffer[j];
          pH_buffer[j]=ph_temp;
        }
      }
    }
    int raw_pH_ADC = 0; // move declaration here
   // raw_pH_ADC = 0;  // Reset before accumulation -- NEW CODE
    //sum the center 6 adc values
    for(int i=2;i<8;i++){
      raw_pH_ADC += pH_buffer[i];
    }
    //divide the summed values by 6 to find average of the center 6 values
    raw_pH_ADC /= 6; 
    
    Serial.print("raw pH ADC: ");
    Serial.println(raw_pH_ADC);

    // calculate mV from raw adc
    pH_mV = (float(raw_pH_ADC)/4095.0) * 3300.0; // 3300.0 (float) to avoid int truncation
    /*
    Serial.print("pH mV: ");
    Serial.println(pH_mV);
    */
    // convert mV to pH
      
    measured_ph = 7 + ((pH_mV - 1100)/59.16) + ph_offset; // 1100 is neutral point
    /*
    Serial.print("Measured pH: ");
    Serial.println(measured_ph);
    */  
  }

  if (abs(measured_ph-targetPH)>0.30){ // 0.3 is the acceptable margin
    ph_sts = false;
  }
  if (abs(measured_ph-targetPH)<=0.30){
    ph_sts = true;
  }
}

void ec(){
  if(millis()-lastECRead > 5000){
    
    
    for (int i = 0; i<10; i++){
      ec_buffer[i] = analogRead(EC_SENSOR);
    }

    for(int i=0;i<9;i++) {
      for(int j=i+1;j<10;j++){
        if(ec_buffer[i]>ec_buffer[j]){  
          ec_temp = ec_buffer[i];
          ec_buffer[i]=ec_buffer[j];
          ec_buffer[j]=ec_temp;
        }
      }  
    }

    for(int i=2;i<8;i++){
      raw_EC_ADC += ec_buffer[i];
    }

    raw_EC_ADC /= 6; 
    /*
    Serial.print("raw EC ADC: ");
    Serial.println(raw_EC_ADC);
*/
    ec_mV = float(raw_EC_ADC / 4095.0) * 3300.0;
    measured_ec = ec_mV*(20.0/23.0) + ec_offset; // 20/23 is the ratio between max output and max voltage
    /*

    float compensationCoefficient = 1.0 + 0.02 * (water_temp - 25.0);
    ec_mV /= -compensationCoefficient;

    // convert mV to EC
    measured_ec = ((133.42 * pow(ec_mV, 3) )
                    - (255.86 * pow(ec_mV, 2))
                    + (857.39 * ec_mV));
  */
    /*
    Serial.print("measured EC: ");
    Serial.println(measured_ec);
    Serial.print("EC mV: ");
    Serial.println(ec_mV);
    
    Serial.print("Measured Error: ");
    Serial.println(abs(measured_ec - targetEC));
    Serial.print("EC Status: ");
    Serial.println(ec_sts);
*/
    lastECRead = millis();
   // Serial.print("Time function check: ");
  //  Serial.println(ArduinoCloud.getLocalTime());

}
  // error check
  if (abs(measured_ec-targetEC) > 100){ // 100 is the acceptable margin
    ec_sts = false;
  }
  if (abs(measured_ec-targetEC)<=100){
    ec_sts = true;
  }
  
}
/* - this function is redundant
void ecCalibration(){
  if (ec_cal_now){
    float difference = manual_ec - measured_ec;
    ec_offset = difference; 
    ec_cal_now = false; // reset calibration trigger
  }
}
*/
//void resetEC



/*
  File to store all of the growth recipes
  The order of the recipes in the array is very important. The data is retreived by attaching an integer
  to a selector variable based on the user selection in the dashboard, then the code goes to that int 
  address in the array, blindly trusting that the intended and actual recipes match based on the array
  position. This data should be stored in an external spreadsheet. This should probably be alphabatized?
*/

struct Recipe {
    const char* name;
    float ph;
    int ec;
};


Recipe recipes[] = {
{"Leafy Greens", 6.1,1900},
{"Kale", 6.1, 1900},
{"Lettuce", 5.9, 1500},
{"Mustard Greens", 6.1, 1900},
{"Basil", 6.1, 1900},
{"Viola", 6.1, 1500},
{"Nasturtium", 6.3, 1800},
{"Bok Choy", 6.1, 1800},
{"Arugula", 6.3, 1800},
{"Thyme", 6.2, 1800},
{"Garlic Chive", 6.3, 1800},
{"Collards", 6.1, 2000},
{"Leek", 6.2, 1800},
{"Cilantro", 6.3, 1800},
{"Lemongrass", 6.1, 1900},
{"Dill", 6.1, 1700},
{"Strawberry", 6.0, 1500},
{"Spinach", 6.3, 1200},
{"Sorrel", 6.0, 1600},
{"Herb", 6.1, 1200},
{"Mint", 6.1, 1800},
{"Shiso", 6.1, 1800},
};
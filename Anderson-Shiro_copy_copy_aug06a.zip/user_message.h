#include "solution_calc.h"  // provides ec_mod(level)

// --- System and input state flags ---
bool waitingForWaterLevel = false;
bool waitingForNutrientAddition = false;
bool waitingForCalibration = false;
bool waitingForECCalibrationConfirmation = false;
bool waitingForResetConfirmation = false;
bool waitingForECResetConfirmation = false;
bool waitingForECCalibration = false;
bool waitingForPHCalibrationConfirmation = false;
bool waitingForPHCalibration = false;
bool waitingForPHResetConfirmation = false;
bool waitingForpHAddition = false;

bool waitingForECRecheck = false;
unsigned long ecRecheckStartTime = 0;

bool waitingForPHRecheck = false;
unsigned long phRecheckStartTime = 0;

// One-shot warning flags
bool ecWarningSent = false;

bool phWarningSent = false;

bool wtrLevelWarningSent = false;

// to store the water level for nutrient calculation recheck
float tempWaterLevel;

// Arduino Cloud messenger variable (both output & input)
//String esp_message = "";

// Track last sent message to detect real user replies
String lastSentMessage = "";

// Are we waiting for the user to reply to the last message?
bool waitingForUserInput = false;


// Helper: send a message & await user reply
void sendMessage(const String &message) {
 // Serial.println("sendMessage called with message: " + message);
  esp_message = message;
  lastSentMessage = message;
  waitingForUserInput = true;
}

void refresh() {
  if (millis() < 30000) {
    return; // Still within the first 30 seconds, don't refresh yet
  }
  //if water level is below required level
  if (!waterLevelSts){
    //only send once per fault
    if (!wtrLevelWarningSent){
      sendMessage("⚠️  The water level is too low!\n"
        "The pump has been automatically shut off to prevent overheating and will not turn back on until more water is added to the primary tank.\n"
        "Please fill the primary tank to the 6 mark.");
      wtrLevelWarningSent = true;
    }
  }

  if(wtrLevelWarningSent && waterLevelSts){ // clear flag if the water level is restored
    wtrLevelWarningSent = false;
  }

  // if EC is out of target range, else if because pump shut off is a higher priority
  else if (!ec_sts) {
    // only send warning once per fault
    if (!waitingForWaterLevel && !ecWarningSent) { 
  
      if (targetEC - measured_ec >= 100) {
        sendMessage("⚠️ EC too low!\nReply with water level (check tank graduations)");
        waitingForUserInput = true; 
        waitingForWaterLevel = true;
        ecWarningSent = true;
      } 
      else {
        sendMessage("⚠️ EC too high!\nReply with water level (check tank graduations)");
        waitingForUserInput = true; 
        waitingForWaterLevel = true;
        ecWarningSent = true;
      }
    } 
  }
      if (waitingForECRecheck) {
    if (millis() - ecRecheckStartTime >= 600000) {  // 600,000 ms = 10 minutes   
      waitingForECRecheck = false;
      
      // Inform user
      if (!ec_sts) {
        // separate logic for low vs high
        if (targetEC - measured_ec >= 100){
          String correction = "⚠️ After waiting, EC is still out of range.\nAdd " + String(ec_mod(tempWaterLevel)) + " mL of Moonflower Boost solution to the tank.\nMix thoroughly then reply 'done'.";
          sendMessage(correction);
          waitingForUserInput = true; 
          waitingForNutrientAddition = true; // call wait and check process again
        }
        if (measured_ec - targetEC >= 100){
          String correction = "⚠️ After waiting, EC is still out of range.\nPlease verify and reply with the current tank level (check tank graduations).";
          sendMessage(correction);
          waitingForUserInput = true;
          waitingForWaterLevel = true;
        }
      } 
      
      else {
        sendMessage("✅ After waiting, EC is now within target range!");
        ecWarningSent = false; // close warning session if good.
      }
  }
}
    
    
// else if because EC should be normalized first
 else if (!ph_sts){
   if (!waitingForWaterLevel && !phWarningSent){
    //pH too high
    if(targetPH - measured_ph <= -0.3){
      sendMessage("⚠️ pH is too high!\nReply with water level (check tank graduations)");
      waitingForUserInput = true; 
      waitingForWaterLevel = true;
      phWarningSent = true;
    }
    //pH too low
    if(targetPH - measured_ph >= -0.3){
      sendMessage("⚠️ pH is too low!\nReply with water level (check tank graduations)");
      waitingForUserInput = true; 
      waitingForWaterLevel = true;
      phWarningSent = true;
    }
   }
 }
   // recheck
   if (waitingForPHRecheck){
     // SHORTENED TO 10 SEC FOR TEST ///
     if (millis() - phRecheckStartTime >= 600000){ // 600,000 ms = 10 minutes
       waitingForPHRecheck = false;
       
       if(!ph_sts){
         String solutionSelect;
         if (targetPH < measured_ph){
           solutionSelect = "DOWN";
         }
         if (targetPH > measured_ph){
           solutionSelect = "UP";
         }
         String correction = "⚠️ After waiting, pH is still out of range.\nAdd " + String(ph_mod(tempWaterLevel)) + " mL of Moonflower pH " + solutionSelect + " solution to the tank.\nMix thoroughly then reply 'done'.";
         sendMessage(correction);
         waitingForUserInput = true; 
         waitingForpHAddition = true; // call wait and check process again
       }

       else{
         sendMessage("✅ After waiting, pH is now within target range!");
         phWarningSent = false; // close warning session if good.
       }
     }
   }
  
else if(!waitingForUserInput) {
    // EC back in range → reset warning logic
    sendMessage("✅ All GroPod systems nominal!");
    waitingForUserInput = true;
  }
  
}
void userMessage(String input); // declaring this function

// Check if user has replied (esp_message changed)
void checkUserInput() {
  if (waitingForUserInput && esp_message != lastSentMessage) {
    String input = esp_message;
    input.toLowerCase();
    waitingForUserInput = false;
    userMessage(input);
  }
}

// Process actual user input
void userMessage(String input) {
  // "check water" command
  if (input == "check water") {
    sendMessage("📏 Checking water level...\nReply with approximate level based on tank graduations.");
    waitingForWaterLevel = true;
    return;
  }

  // Water level response
if (waitingForWaterLevel) {
    float level = input.toFloat();
    tempWaterLevel= level;
    if (level > 0.0) {  // valid number
        waitingForWaterLevel = false;  // <<< CLEAR THIS FLAG
        //ecWarningSent = false;          // <<< CLEAR THIS FLAG TOO - dont clear yet, clear after recheck
      if (ecWarningSent){  // if we are currently adjusting EC
        if (targetEC - measured_ec >= 50){ // check if EC is too low or too high. TOO LOW
          if (level <= 2.0) {
              sendMessage("💧 Water is LOW.\n➡️ Fill water tank to the 6 line."); // Need to continue building on this
          } 
          
          else if (level <= 9.0) {
              String correction = "Add " + String(ec_mod(level)) + " mL of Moonflower Boost solution to the tank.\nMix thoroughly then reply 'done'.";
              sendMessage(correction);
          } 
          
          else {
              sendMessage("❌ Invalid water level. Please enter a value between 1 and 9.");
              waitingForWaterLevel = true; // (optionally re-arm if input was bad)
          }
  
          waitingForNutrientAddition = true;
        }
        if (measured_ec - targetEC >= 50){ // EC too high
          if (level <= 5.0){
            sendMessage("Add 3 gallons of fresh water to the lower tank.\nMix thoroughly then reply 'done'.");
            waitingForNutrientAddition = true; // pretty sure we can piggy back off of this flag
          }
          if (level > 5.0){
            sendMessage("Remove 3 gallons of water from the tank and replace with 3 gallons of fresh water.\n Mix thoroughly then reply 'done'.");
            waitingForNutrientAddition = true;
          }
        }
        
      }
      else if (phWarningSent){
        if (level <= 2.0) {
            sendMessage("💧 Water is LOW.\n➡️ Fill water tank to the 6 line."); // Need to continue building on this
        } 
        
        else if (level <= 9.0) {
          String solutionSelect;
          if (targetPH < measured_ph){ // lowering pH 
            solutionSelect = "DOWN";
          }
          else{ // raising pH
            solutionSelect = "UP";
          }
          String correction = "Add " + String(ph_mod(level)) + " mL of Moonflower pH " + solutionSelect + " solution to the tank.\nMix thoroughly then reply 'done'.";
          sendMessage(correction);
        } 
        
        else {
            sendMessage("❌ Invalid water level. Please enter a value between 1 and 9.");
            waitingForWaterLevel = true; // (optionally re-arm if input was bad)
        }

        waitingForpHAddition = true;
        
      }
    }
}

  // Nutrient addition confirmation, wait for system cycle
  if (waitingForNutrientAddition && input == "done") {
    sendMessage("✅ Nutrient solution adjusted!\n⏱️ Wait 10 minutes for the system to cycle adjusted solution.\n📐 GroPod will automatically recheck EC in 10 minutes.");
    waitingForNutrientAddition = false;

    // Start 10 min timer
    ecRecheckStartTime = millis();
    waitingForECRecheck = true;
    return;
  }


  if(waitingForpHAddition && input == "done"){
    sendMessage("✅ pH adjusted!\n⏱️ Wait 10 minutes for the system to cycle adjusted solution.\n📐 GroPod will automatically recheck the pH in 10 minutes.");
    waitingForpHAddition = false;

    // start 10 min timer
    phRecheckStartTime = millis();
    waitingForPHRecheck = true;
    return;
  }

  // Calibration entry
  if (input == "calibrate") {
    sendMessage("🔧 Calibration Mode:\nWould you like to calibrate the EC or pH sensor?\nReply 'ec' or 'ph'");
    waitingForCalibration = true;
    return;
  }

  // Choose sensor to calibrate
  if (waitingForCalibration) {
    if (input == "ec") {
      sendMessage("Now calibrating the EC Sensor.\nEnter the known EC value (e.g., 1200 for 1200 µS/cm)");
      waitingForCalibration = false;
      waitingForECCalibration = true;
    } else if (input == "ph") {
      sendMessage("Now calibrating the pH sensor.\nEnter the known pH value (e.g., 6.21)");
      waitingForCalibration = false;
      waitingForPHCalibration = true;
    }
    return;
  }

  // pH calibration value entry
  if (waitingForPHCalibration) {
    float val = input.toFloat();
    if (val > 0.0) {
      manual_ph = val;
      float diff = manual_ph - measured_ph;
      sendMessage("📊 Measured pH: " + String(measured_ph) + "\n" +
                  "🔬 Known pH: " + String(manual_ph) + "\n" +
                  "⚠️ Adjust by " + String(diff) + "\nReply 'yes' to confirm, 'no' to cancel.");
      waitingForPHCalibration = false;
      waitingForPHCalibrationConfirmation = true;
    }
    return;
  }

  // pH calibration confirmation
  if (waitingForPHCalibrationConfirmation) {
    if (input == "yes") {
      ph_cal_now = true;
      onPhCalNowChange();
      sendMessage("✅ Calibration updated!");
      waitingForPHCalibrationConfirmation = false;
      waitingForUserInput = true;
      refresh();
    } else if (input == "no") {
      sendMessage("❌ Calibration canceled.");
      waitingForPHCalibrationConfirmation = false;
      waitingForUserInput = true;
    }
    return;
  }

  // EC calibration value entry
  if (waitingForECCalibration) {
    int val = input.toInt();
    if (val > 0) {
      manual_ec = val;
      int diff = manual_ec - measured_ec;
      sendMessage("📊 Measured EC: " + String(measured_ec) + " µS/cm\n" +
                  "🔬 Known EC: " + String(manual_ec) + " µS/cm\n" +
                  "⚠️ Adjust by " + String(diff) + " µS/cm?\nReply 'yes' to confirm, 'no' to cancel.");
      waitingForECCalibration = false;
      waitingForECCalibrationConfirmation = true;
    }
    return;
  }

  // EC calibration confirmation
  if (waitingForECCalibrationConfirmation) {
    if (input == "yes") {
      ec_cal_now = true;
      onEcCalNowChange();
      sendMessage("✅ Calibration updated!");
      waitingForECCalibrationConfirmation = false;
      waitingForUserInput = true;
      ecWarningSent = false;
      refresh();
    } else if (input == "no") {
      sendMessage("❌ Calibration canceled.");
      waitingForECCalibrationConfirmation = false;
      waitingForUserInput = true;
      refresh();
    }
    return;
  }

  // Reset command
  if (input == "reset") {
    sendMessage("Which sensor would you like to reset?\nReply 'ec' or 'ph'");
    waitingForResetConfirmation = true;
    return;
  }

  // Choose sensor to reset
  if (waitingForResetConfirmation) {
    if (input == "ec") {
      sendMessage("⚠️ Are you sure you want to reset EC calibration?\nReply 'yes' to confirm, 'no' to cancel.");
      waitingForResetConfirmation = false;
      waitingForECResetConfirmation = true;
    } else if (input == "ph") {
      sendMessage("⚠️ Are you sure you want to reset pH calibration?\nReply 'yes' to confirm, 'no' to cancel.");
      waitingForResetConfirmation = false;
      waitingForPHResetConfirmation = true;
    }
    return;
  }

  // EC reset confirmation
  if (waitingForECResetConfirmation) {
    if (input == "yes") {
      ec_rst = true;
      onEcRstChange();
      sendMessage("🔄 EC calibration reset to defaults!");
      waitingForECResetConfirmation = false;
      waitingForUserInput = true;
    } else if (input == "no") {
      sendMessage("❌ EC reset canceled.");
      waitingForECResetConfirmation = false;
      waitingForUserInput = true;
    }
    return;
  }

  // pH reset confirmation
  if (waitingForPHResetConfirmation) {
    if (input == "yes") {
      ph_rst = true;
      onPhRstChange();
      sendMessage("🔄 pH calibration reset to defaults!");
      waitingForPHResetConfirmation = false;
      waitingForUserInput = true;
    } else if (input == "no") {
      sendMessage("❌ pH reset canceled.");
      waitingForPHResetConfirmation = false;
      waitingForUserInput = true;
    }
    return;
  }
}
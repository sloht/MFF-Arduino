// calibration constants:
//   • EC change per mL = 8.32 µS/cm
//   • Calibration tank volume = 10.41 L
//   ⇒ EC_ML_SCALAR = 8.32 × 10.41 = 86.528
const float EC_ML_SCALAR = 86.528; 

/*
===== pH calculations =====
    pH change per mL = -0.295
    Calibration tank volume = 10.41 L
    pH scalar = -0.295 * 10.41 = -3.068
*/ 
const float PH_D_SCALAR = -3.068;

const float PH_U_SCALAR = 0.273;

int ec_mod(float tank_level){ //helper function to return the desired nutrient level
  int volumeToAdd_mL;
  float sysWater;
  // convert tank level to liter and include circulating volume
  sysWater = (tank_level / 3.76) + 11.4;
  
  volumeToAdd_mL = ((targetEC-measured_ec)*sysWater)/EC_ML_SCALAR;
  return volumeToAdd_mL;
}

int ph_mod(float tank_level){
  int volumeToAdd_mL;
  float sysWater;
  // convert tank level to liters and include circulating volume
  sysWater = (tank_level / 3.76) + 11.4;
  if (targetPH < measured_ph){ // lowering pH 
    volumeToAdd_mL = ((targetPH-measured_ph)*sysWater)/PH_D_SCALAR;
  }
  if (measured_ph < targetPH){ // raising pH
    volumeToAdd_mL = ((targetPH-measured_ph)*sysWater)/PH_U_SCALAR; 
  }
  return volumeToAdd_mL;
}